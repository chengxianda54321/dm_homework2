clear;
clc; 
data=importdata('Building_Permits.csv');
load 'testdata.mat'%读入事务矩阵（每行代表一个事务，每列代表一个项）
load 'processed_permits.mat'
load 'attribute.mat'
% load 'Nominal2Category_Label\Block.mat'
% load 'Nominal2Category_Label\Completed_Date.mat'
% load 'Nominal2Category_Label\Current_Status_Date.mat'
% load 'Nominal2Category_Label\Current_Status.mat'
% load 'Nominal2Category_Label\Description.mat'
% load 'Nominal2Category_Label\Existing_Use.mat'
% load 'Nominal2Category_Label\Filed_Date.mat'
% load 'Nominal2Category_Label\Fire_Only_Permit.mat'
% load 'Nominal2Category_Label\First_Construction_Document_Date.mat'
% load 'Nominal2Category_Label\Issued_Date.mat'
% load 'Nominal2Category_Label\Location.mat'
% load 'Nominal2Category_Label\Lot.mat'
% load 'Nominal2Category_Label\Neighborhoods_Analysis_Boundaries.mat'
% load 'Nominal2Category_Label\Permit_Creation_Date.mat'
% load 'Nominal2Category_Label\Permit_Expiration_Date.mat'
% load 'Nominal2Category_Label\Permit_Number.mat'
% load 'Nominal2Category_Label\Plansets.mat'
% load 'Nominal2Category_Label\Proposed_Use.mat'
% load 'Nominal2Category_Label\Record_ID.mat'
% load 'Nominal2Category_Label\Site_Permit.mat'
% load 'Nominal2Category_Label\Street_Name.mat'
% load 'Nominal2Category_Label\Street_Number_Suffix.mat'
% load 'Nominal2Category_Label\Street_Number.mat'
% load 'Nominal2Category_Label\Street_Suffix.mat'
% load 'Nominal2Category_Label\Structural_Notification.mat'
% load 'Nominal2Category_Label\Supervisor_District.mat'
% load 'Nominal2Category_Label\TIDF_Compliance.mat'
% load 'Nominal2Category_Label\Unit_Suffix.mat'
% load 'Nominal2Category_Label\Unit.mat'
% load 'Nominal2Category_Label\Voluntary_Soft_Story_Retrofit.mat'
% load 'Nominal2Category_Label\Zipcode.mat'
total_attribute_number(:,21)=-total_attribute_number(:,21);
total_attribute_number(:,22)=-total_attribute_number(:,22);
total_attribute_number(:,26)=-total_attribute_number(:,26);
total_attribute_number(:,27)=-total_attribute_number(:,27);
total_attribute_number(:,29)=-total_attribute_number(:,29);
total_attribute_number(:,31)=-total_attribute_number(:,31);
total_attribute_number(:,2)=-total_attribute_number(:,2);
total_attribute_number(:,3)=-total_attribute_number(:,3);
total_attribute_number(:,34)=-total_attribute_number(:,34);
total_attribute_number(:,35)=-total_attribute_number(:,35);
total_attribute_number(:,36)=-total_attribute_number(:,36);
total_attribute_number(:,37)=-total_attribute_number(:,37);
total_attribute_number(total_attribute_number==0)=-1.5;
total_attribute_number(isnan(total_attribute_number)) = 0;
%PrintTransactions(total_attribute_number);%打印出事务
min_sup = 500;%初始化最小支持度
min_conf = 0.7;%初始化最小置信度
rand_index = randi(size(total_attribute_number,1),1000,1);
temp_attribute_number = total_attribute_number(rand_index,:);
[rules_left, rules_right] = Apriori(temp_attribute_number,rand_index, data,attribute, min_sup, min_conf);%运算Apriori算法
PrintRules(temp_attribute_number,rand_index, data,attribute,rules_left, rules_right);%打印强关联规则
